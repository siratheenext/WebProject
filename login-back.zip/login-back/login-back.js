const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;
const cookieParser = require("cookie-parser");

app.use(cookieParser());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use(express.static(path.join(`${__dirname}/css`)))

function access(req, res, next) {
    const Cookie = req.cookies['cookie'];
    console.log(Cookie);
    if (Cookie) {
        console.log("Cookie found:", Cookie);
        next();
    } else {
        console.log("No cookie found. Access denied.");
        res.redirect('/');
    }
}

app.get('/', (req, res) => {
    console.log('Request at /');
    res.sendFile(path.join(`${__dirname}/html/LoginPage.html`));
});

app.get('/admin', access, (req, res) => {
    console.log('Request at /');
    res.sendFile(path.join(`${__dirname}/html/admin.html`));
});

app.get('*', (req, res) => {
    console.log(`Request at ${req.url}`);
    console.log('404: Invalid accessed');
    res.status(404);
});

app.listen(port, () => { 
    console.log(`Server listening on port: ${port}`); 
});