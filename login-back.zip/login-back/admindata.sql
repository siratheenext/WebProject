create database AdminAccounts;
use AdminAccounts;

create table login(
	username varchar(30) not null,
    pw varchar(30) not null,
    primary key(username)
);

insert into login (username,pw) values
	('NokKiWi','Kiwikiwi'),
    ('dewmsr','tenlovelove'),
    ('nextsirathee','moreanycoffee'),
    ('HeangKung','heanglovemoney');
    
create table login_done(
    username varchar(30),
    pw varchar(30),
    saveLogin datetime,
    foreign key(username) references login(username),
    foreign key(username) references login(username)
);

select * from login_done;