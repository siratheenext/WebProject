const express = require("express");
const path=require('path');
const app = express();
const router = express.Router();
app.use(router);
const dotenv = require("dotenv");
const mysql = require('mysql2');
const multer = require("multer");
const fs = require("fs");
dotenv.config();

app.use(express.static(path.join(__dirname, "style"))); // Serves CSS and images
app.use(express.static(path.join(__dirname, "html")))

router.get('/a', (req,res)=>{
    res.send('hellooooooooo');
})

router.get('/admin', (req,res)=>{
    res.sendFile(path.join(__dirname, "/html/admin.html"));
})

router.get('/menu', (req,res)=>{
    res.sendFile(path.join(__dirname, "/html/menu.html"));
})

router.get('/add_admin', (req,res)=>{
    res.sendFile(path.join(__dirname, "/html/add_admin.html"));
})

router.get('/add_menu', (req,res)=>{
    res.sendFile(path.join(__dirname, "/html/add_menu.html"));
})

router.get('/edit_admin', (req,res)=>{
    res.sendFile(path.join(__dirname, "/html/edit_admin.html"));
})

router.get('/edit_menu', (req,res)=>{
    res.sendFile(path.join(__dirname, "/html/edit_menu.html"));
})

router.get('/sidebar_admin', (req, res) => {
    res.sendFile(path.join(__dirname, '/html/sidebar.html'));
});

router.get('/homepage', (req, res) => {
    res.send("Hello, this is homepage");
});

app.listen(process.env.port, () => {
    console.log(`Server listening on port: ${process.env.port}`);
});

