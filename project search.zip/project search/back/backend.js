const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
const mysql = require('mysql2');

dotenv.config();

const app = express();
const PORT = process.env.PORT ;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (CSS, JS, Images, etc.)
app.use(express.static(path.join(__dirname, 'html')));

// Database Connection
const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
        process.exit(1); // Exit the app if the database connection fails
    }
    console.log('Connected DB:', process.env.DB_NAME);
});

// Routes
app.get('/', (req, res) => {
    console.log(`GET request at: ${req.path}`);
    res.sendFile(path.join(__dirname, 'html', 'search.html'));
});

// API to Fetch Products with Filters
app.get('/api/products', (req, res) => {
    let { query, category, price, promotion } = req.query;

    // Base query to get all products
    let sql = 'SELECT * FROM products WHERE 1';

    // Apply filters based on query parameters
    if (query) {
        sql += ` AND (name LIKE '%${query}%' OR category LIKE '%${query}%')`;
    }

    if (category) {
        sql += ` AND category = '${category}'`;
    }

    if (price) {
        if (price === "50") {
            sql += ` AND price < 50`;
        } else if (price === "100") {
            sql += ` AND price BETWEEN 50 AND 100`;
        } else if (price === "101") {
            sql += ` AND price > 100`;
        }
    }

    if (promotion) {
        sql += ` AND promotion = 1`; // Assuming promotion is a boolean (0 or 1)
    }

    db.query(sql, (err, results) => {
        if (err) {
            console.error('Error fetching data from the database:', err);
            res.status(500).json({ error: 'Failed to fetch products' });
            return;
        }
        res.json(results); // Send the fetched data as JSON
    });
});

// Catch-all route for 404 errors
app.use((req, res) => {
    console.error(`404 Error - Route not found: ${req.method} ${req.originalUrl}`);
    res.status(404).send('404 - Page Not Found');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server listening at :${PORT}`);
});
