const express = require('express');
const dotenv = require('dotenv');
const mysql = require('mysql2');
const cors = require('cors');
const path = require('path');
const cookieParser = require("cookie-parser");

const app = express(); 

app.use(express.json());
app.use(express.urlencoded({ extended: true })); //เปลี่ยนฟอร์มให้เป็นobj
dotenv.config();
app.use(cookieParser());

let whiteList = ['http://localhost:3000']

let corsOptions = {
    origin: whiteList, 
    credentials: true, //ส่งคุกกี้
    method: 'GET,POST,PUT,DELETE'
}

app.use(cors(corsOptions));

const connection = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    database: process.env.DB_NAME
});

connection.connect(function(err){
    if (err) throw err;
    console.log(`Connected DB: ${process.env.DB_NAME}`);
});

app.post("/sign-in", async (req, res) => {
    const username = req.body.username;
    const password = req.body.password;
    const recaptcha = req.body.recaptcha;

    if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required." });
    }
    if(!recaptcha){
        return res.status(400).json({ error: "Please complete the reCAPTCHA"});
    }

    const secretKey = "6Ldf6YsqAAAAACVQOpsbUNkLa97Vk7noTCcSjRTR";
    const verificationURL = `https://www.google.com/recaptcha/api/siteverify?secret=${secretKey}&response=${recaptcha}`; //reCaptcha
    
    try {
        const recaptchaResponse = await fetch(verificationURL, { method: "POST" });
        const recaptchaResult = await recaptchaResponse.json();

        if (!recaptchaResult.success) {
            return res.status(400).json({ error: "reCAPTCHA verification failed." });
        }

        const sqlQuery = "SELECT * FROM login WHERE username = ?";
        connection.query(sqlQuery, [username], (err, results) => {
            if (err) {
                console.error("Database Error:", err);
                return res.status(500).json({ error: "An error occurred while processing your request." });
            }

            if (results.length === 0) {
                return res.status(401).json({ error: "Invalid username or password." });
            }

            const admin = results[0];

            if (password !== admin.pw) {  //เปลี่ยนให้เข้ากับดาต้าเบส
                return res.status(401).json({ error: "Invalid username or password." });
            }

            const sessionToken = `cookie-${new Date().getTime()}`;
            const cookieOptions = {
                httpOnly: true,
                maxAge: 24 * 60 * 60 * 1000,
            };
            res.cookie("cookie", sessionToken, cookieOptions);
            res.status(200).json({message: "Login successful", user: {username: admin.username}});

            const loginTime = new Date();
            const loginQuery = "INSERT INTO login_done (username, pw, saveLogin) VALUES (?, ?, ?)";

            connection.query(loginQuery, [admin.username, admin.pw, admin.loginTime], (insertErr) => {
            if (insertErr) {
                console.error("Error inserting login data:", insertErr);
                return res.status(500).json({error: "Failed to record login."});
            }
            console.log(`Login successful by ${username} at ${loginTime}`);
  
        });
        });
    } catch (err) {
        console.error("Error during reCAPTCHA verification:", err);
        return res.status(500).json({ error: "An error occurred while verifying reCAPTCHA." });
    }
});

app.listen(process.env.PORT, () => { 
    console.log(`Server listening on port: ${process.env.PORT}`);
});