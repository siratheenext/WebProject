const express = require('express');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT;
const router = express.Router();
app.use(router)
app.use('/', express.static(path.join(__dirname,'/html')));

router.get('/detail', (req, res) => {
    res.sendFile(path.join(__dirname, 'html', 'description.html'));
});
app.use((req, res) => {
    console.error(`404 Error - Route not found: ${req.method} ${req.originalUrl}`);
    res.status(404).send('404 - Page Not Found');
});

app.listen(PORT, () => {
    console.log(`Server listening at ${PORT}`);
});

