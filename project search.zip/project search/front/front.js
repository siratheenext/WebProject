const express = require('express');
const path = require('path');
const dotenv = require('dotenv');
dotenv.config();

const app = express();
const PORT = process.env.PORT ;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files (CSS, JS, Images, etc.)
app.use(express.static(path.join(__dirname, 'html')));

// Routes
app.get('/', (req, res) => {
    console.log(`GET request at: ${req.path}`);
    res.sendFile(path.join(__dirname, 'html', 'search.html'));
});

// Catch-all route for 404 errors
app.use((req, res) => {
    console.error(`404 Error - Route not found: ${req.method} ${req.originalUrl}`);
    res.status(404).send('404 - Page Not Found');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server listening at ${PORT}`);
});
